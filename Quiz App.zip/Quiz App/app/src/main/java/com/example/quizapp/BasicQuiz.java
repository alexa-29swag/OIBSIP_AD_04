package com.example.quizapp;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BasicQuiz extends AppCompatActivity {

    TextView quiztext, aans, bans, cans, dans;
    List<QuestionsItem> questionsItems;
    int currentQuestions = 0;
    int correct = 0, wrong = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        quiztext = findViewById(R.id.quizText);
        aans = findViewById(R.id.aanswer);
        bans = findViewById(R.id.banswer);
        cans = findViewById(R.id.canswer);
        dans = findViewById(R.id.danswer);

        loadAllQuestions();
        Collections.shuffle(questionsItems);
        setQuestionScreen(currentQuestions);

        aans.setOnClickListener(view -> handleAnswerClick(aans, questionsItems.get(currentQuestions).getAns1()));
        bans.setOnClickListener(view -> handleAnswerClick(bans, questionsItems.get(currentQuestions).getAns2()));
        cans.setOnClickListener(view -> handleAnswerClick(cans, questionsItems.get(currentQuestions).getAns3()));
        dans.setOnClickListener(view -> handleAnswerClick(dans, questionsItems.get(currentQuestions).getAns4()));
    }

    private void handleAnswerClick(TextView selectedOption, String selectedAnswer) {
        resetOptions();
        enableOptions(false); // Disable all after one selection

        if (selectedAnswer.equals(questionsItems.get(currentQuestions).getCorrect())) {
            correct++;
            selectedOption.setBackgroundColor(ContextCompat.getColor(this, R.color.green));
        } else {
            wrong++;
            selectedOption.setBackgroundColor(ContextCompat.getColor(this, R.color.red));
        }

        selectedOption.setTextColor(ContextCompat.getColor(this, R.color.white));

        new Handler().postDelayed(() -> {
            currentQuestions++;
            setQuestionScreen(currentQuestions);
        }, 500);
    }

    private void setQuestionScreen(int currentQuestions) {
        if (currentQuestions >= questionsItems.size()) {
            Intent intent = new Intent(BasicQuiz.this, ResultActivity.class);
            intent.putExtra("correct", correct);
            intent.putExtra("wrong", wrong);
            startActivity(intent);
            finish();
            return;
        }

        quiztext.setText(questionsItems.get(currentQuestions).getQuestions());
        aans.setText(questionsItems.get(currentQuestions).getAns1());
        bans.setText(questionsItems.get(currentQuestions).getAns2());
        cans.setText(questionsItems.get(currentQuestions).getAns3());
        dans.setText(questionsItems.get(currentQuestions).getAns4());

        resetOptions();
        enableOptions(true);
    }

    private void resetOptions() {
        int white = ContextCompat.getColor(this, R.color.white);
        int defaultText = ContextCompat.getColor(this, R.color.text_secondary_color);

        aans.setBackgroundColor(white);
        bans.setBackgroundColor(white);
        cans.setBackgroundColor(white);
        dans.setBackgroundColor(white);

        aans.setTextColor(defaultText);
        bans.setTextColor(defaultText);
        cans.setTextColor(defaultText);
        dans.setTextColor(defaultText);
    }

    private void enableOptions(boolean enable) {
        aans.setEnabled(enable);
        bans.setEnabled(enable);
        cans.setEnabled(enable);
        dans.setEnabled(enable);
    }

    private void loadAllQuestions() {
        questionsItems = new ArrayList<>();
        String jsonquiz = loadJsonFromAsset("easyquestion.json");
        try {
            JSONObject jsonObject = new JSONObject(jsonquiz);
            JSONArray questions = jsonObject.getJSONArray("easyquestion");
            for (int i = 0; i < questions.length(); i++) {
                JSONObject question = questions.getJSONObject(i);

                String questionsString = question.getString("question");
                String answer1String = question.getString("ans1");
                String answer2String = question.getString("ans2");
                String answer3String = question.getString("ans3");
                String answer4String = question.getString("ans4");
                String correctString = question.getString("correct");

                questionsItems.add(new QuestionsItem(questionsString, answer1String, answer2String, answer3String, answer4String, correctString));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private String loadJsonFromAsset(String s) {
        String json = "";
        try {
            InputStream inputStream = getAssets().open(s);
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return json;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        MaterialAlertDialogBuilder materialAlertDialogBuilder = new MaterialAlertDialogBuilder(BasicQuiz.this);
        materialAlertDialogBuilder.setTitle(R.string.app_name);
        materialAlertDialogBuilder.setMessage("Are you sure you want to exit the quiz?");
        materialAlertDialogBuilder.setNegativeButton(android.R.string.no, (dialogInterface, i) -> dialogInterface.dismiss());
        materialAlertDialogBuilder.setPositiveButton(android.R.string.yes, (dialogInterface, i) -> {
            startActivity(new Intent(BasicQuiz.this, MainActivity.class));
            finish();
        });
        materialAlertDialogBuilder.show();
    }
}
