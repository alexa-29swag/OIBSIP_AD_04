package com.example.quizapp;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DifficultQuiz extends AppCompatActivity {

    TextView quiztext, aans, bans, cans, dans;
    List<QuestionsItem> questionsItems;
    int currentQuestions = 0;
    int correct = 0, wrong = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        quiztext = findViewById(R.id.quizText);
        aans = findViewById(R.id.aanswer);
        bans = findViewById(R.id.banswer);
        cans = findViewById(R.id.canswer);
        dans = findViewById(R.id.danswer);

        loadAllQuestions();
        Collections.shuffle(questionsItems);
        setQuestionScreen(currentQuestions);

        aans.setOnClickListener(v -> handleAnswerClick(aans, questionsItems.get(currentQuestions).getAns1()));
        bans.setOnClickListener(v -> handleAnswerClick(bans, questionsItems.get(currentQuestions).getAns2()));
        cans.setOnClickListener(v -> handleAnswerClick(cans, questionsItems.get(currentQuestions).getAns3()));
        dans.setOnClickListener(v -> handleAnswerClick(dans, questionsItems.get(currentQuestions).getAns4()));
    }

    private void handleAnswerClick(TextView selectedOption, String selectedAnswer) {
        resetOptions();
        enableOptions(false); // Disable all after selection

        if (selectedAnswer.equals(questionsItems.get(currentQuestions).getCorrect())) {
            correct++;
            selectedOption.setBackgroundColor(ContextCompat.getColor(this, R.color.green));
        } else {
            wrong++;
            selectedOption.setBackgroundColor(ContextCompat.getColor(this, R.color.red));
        }

        selectedOption.setTextColor(ContextCompat.getColor(this, R.color.white));

        new Handler().postDelayed(() -> {
            currentQuestions++;
            setQuestionScreen(currentQuestions);
        }, 500);
    }

    private void setQuestionScreen(int currentQuestions) {
        if (currentQuestions >= questionsItems.size()) {
            Intent intent = new Intent(DifficultQuiz.this, ResultActivity.class);
            intent.putExtra("correct", correct);
            intent.putExtra("wrong", wrong);
            startActivity(intent);
            finish();
            return;
        }

        quiztext.setText(questionsItems.get(currentQuestions).getQuestions());
        aans.setText(questionsItems.get(currentQuestions).getAns1());
        bans.setText(questionsItems.get(currentQuestions).getAns2());
        cans.setText(questionsItems.get(currentQuestions).getAns3());
        dans.setText(questionsItems.get(currentQuestions).getAns4());

        resetOptions();
        enableOptions(true);
    }

    private void resetOptions() {
        int white = ContextCompat.getColor(this, R.color.white);
        int textDefault = ContextCompat.getColor(this, R.color.text_secondary_color);

        aans.setBackgroundColor(white);
        bans.setBackgroundColor(white);
        cans.setBackgroundColor(white);
        dans.setBackgroundColor(white);

        aans.setTextColor(textDefault);
        bans.setTextColor(textDefault);
        cans.setTextColor(textDefault);
        dans.setTextColor(textDefault);
    }

    private void enableOptions(boolean enable) {
        aans.setEnabled(enable);
        bans.setEnabled(enable);
        cans.setEnabled(enable);
        dans.setEnabled(enable);
    }

    private void loadAllQuestions() {
        questionsItems = new ArrayList<>();
        String jsonquiz = loadJsonFromAsset("difficultquestion.json");
        try {
            JSONObject jsonObject = new JSONObject(jsonquiz);
            JSONArray questions = jsonObject.getJSONArray("difficultquestion");
            for (int i = 0; i < questions.length(); i++) {
                JSONObject question = questions.getJSONObject(i);

                String questionsString = question.getString("question");
                String answer1String = question.getString("ans1");
                String answer2String = question.getString("ans2");
                String answer3String = question.getString("ans3");
                String answer4String = question.getString("ans4");
                String correctString = question.getString("correct");

                questionsItems.add(new QuestionsItem(
                        questionsString,
                        answer1String,
                        answer2String,
                        answer3String,
                        answer4String,
                        correctString));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private String loadJsonFromAsset(String s) {
        String json = "";
        try {
            InputStream inputStream = getAssets().open(s);
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return json;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        MaterialAlertDialogBuilder dialogBuilder = new MaterialAlertDialogBuilder(DifficultQuiz.this);
        dialogBuilder.setTitle(R.string.app_name);
        dialogBuilder.setMessage("Are you sure you want to exit the quiz?");
        dialogBuilder.setNegativeButton(android.R.string.no, (dialogInterface, i) -> dialogInterface.dismiss());
        dialogBuilder.setPositiveButton(android.R.string.yes, (dialogInterface, i) -> {
            startActivity(new Intent(DifficultQuiz.this, MainActivity.class));
            finish();
        });
        dialogBuilder.show();
    }
}
